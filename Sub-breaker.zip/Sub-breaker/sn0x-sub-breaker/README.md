![Sn0x-sub-breaker](slideshow/hover_logo.png)

### An open-sourced extension that that bypasses paywalls and blocks ads. Made so you can access important information with ease and without distractions.

![Sn0x-sub-breaker_1](slideshow/ss8/1.png)
![Sn0x-sub-breaker_2](slideshow/ss8/2.png)
![Sn0x-sub-breaker_3](slideshow/ss8/3.png)

Access more content on the internet. Made so you can access important information, on topics like coronavirus and elections, with ease and without paywalls, subscription walls, ads, and tracking modules. 

# Installation

## 1)Download Locally: 
**Google Chrome**
2. Unzip the file and you should have a folder named `sn0x-sub-breaker`.
3. In Chrome go to the extensions page (`chrome://extensions`).
4. Enable Developer Mode.
5. Drag the `dist` folder that is in `sn0x-sub-breaker` onto anywhere on the Chrome page to import it! (do not delete the folder afterwards)
6. Enjoy!

## Notes

-The only permissions/settings the extension utilizes are for webRequest and cookie functionality, and nothing more.

-May not work on some websites.


Disclaimer: 
Do not use this extension to violate the terms of service/use of any website.